<html>
<head>
	<title>Welcome Admin!</title>
	<link rel="stylesheet" type="text/css" href="adminPage.css"/>
</head>

<body>
	
	<a href="index.html">Logout</a>
	<a href="adminAddNewAdmin_parse.php">Add New Admin</a>
	<div id="container">
		<div id="header">
			<h1>FSKKP-Alumni Management System</h1>
		
		</div>
		<div id="content">
		
			<div id="nav">
				<h2>Navigation</h2>
				
				<ul>
					<li><a href="">MAIN PAGE*</li>
					<li><a href="adminManageMember.php">MANAGE MEMBERSHIP</a></li>
					<li><a>MANAGE FINANCIAL</a></li>
						<ul>
						<li><a href="adminManageFinance(MembershipFee).php">Manage Membership Fee.</a></li>
						<li><a href="adminManageFinance(Donation).php">Manage Donation.</a></li>
						<li><a href="adminManageFinance(Expenses).php">Manage Expenses.</a></li>
						</ul>
					<li><a href="adminA&E.php">ANNOUNCEMENT/EVENT</a></li>
					<li><a href="adminEforum.php">E-FORUM</a></li>
				
				</ul>
			</div>
			
			<div id="main">
			
				<h2>Welcome Admin!</h2>
			</div>
			
			
		
		</div>
		
		<div id="footer">
		
		<p> Copyright &copy; 2018 Chan Pui Fen & Kong Shin Yee</p>
		
		</div>
		
	</div>

</body>



</html>