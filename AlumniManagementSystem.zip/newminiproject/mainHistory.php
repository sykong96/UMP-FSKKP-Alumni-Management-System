<!DOCTYPE html>
<html>
<head>
	<title>Main Page</title>
	<link rel="stylesheet" type="text/css" href="main.css"/>
</head>

<body>
<a href="login.php" color="red">Member Login</a>
<a href="adminlogin.php" color="red">Admin Login</a>
<div class="header"></div>

<center><h1>Welcome to UMP-FSKKP Alumni Management System</h1></center>

<ul>
  <li><a href="index.html">Main</a></li>
  <li><a href="">History</a></li>
  <li><a href="mainOChart.php">Organization Chart</a></li>
  <li><a href="mainContact.php">Contact</a></li>
  <li><a href="mainProcess.php">Process</a></li>
  <li><a href="mainAddress.php">Address & Location</a></li>
</ul>


<center><h2>History</h2><center>
<strong><center><p class = "style1">
UMP-FSKKP Alumni holds an official long history service with UMP. It was initialized on March 1st 2008 with an aim to build a continues relationship between UMP and its graduates both socially and professionally. Throughout the years of service, UMP-FSKKP Alumni has gain the trust and feeling of dependable among the graduates towards UMP.

<br><br></center></strong>


</body>
</html>