<!DOCTYPE html>
<html>
<head>
	<title>Main Page</title>
	<link rel="stylesheet" type="text/css" href="main.css"/>
</head>

<body>
<a href="login.php" color="red">Member Login</a>
<a href="adminlogin.php" color="red">Admin Login</a>
<div class="header"></div>

<center><h1>Welcome to UMP-FSKKP Alumni Management System</h1></center>

<ul>
  <li><a href="index.html">Main</a></li>
  <li><a href="mainHistory.php">History</a></li>
  <li><a href="">Organization Chart</a></li>
  <li><a href="mainContact.php">Contact</a></li>
  <li><a href="mainProcess.php">Process</a></li>
  <li><a href="mainAddress.php">Address & Location</a></li>
</ul>


<center><h2>Organization Chart</h2><center>
<strong><center><p class = "style1">
<center><img src = "oc.png" alt = "OC" style="width:800px;height:500px;"></center>
<br><br></center></strong>


</body>
</html>