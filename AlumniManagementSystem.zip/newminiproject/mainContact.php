<!DOCTYPE html>
<html>
<head>
	<title>Main Page</title>
	<link rel="stylesheet" type="text/css" href="main.css"/>

</head>

<body>
<a href="login.php" color="red">Member Login</a>
<a href="adminlogin.php" color="red">Admin Login</a>
<div class="header"></div>

<center><h1>Welcome to UMP-FSKKP Alumni Management System</h1></center>

<ul>
  <li><a href="index.html">Main</a></li>
  <li><a href="mainHistory.php">History</a></li>
  <li><a href="mainOChart.php">Organization Chart</a></li>
  <li><a href="">Contact</a></li>
  <li><a href="mainProcess.php">Process</a></li>
  <li><a href="mainAddress.php">Address & Location</a></li>
</ul>


<center><h2>Stay in Contact</h2><center>
<strong><center><p class = "style1">
Do you need more information? Have a look at our website. Or you can contact Services Center of our Faculty: fskkpoffice@ump.my or phone 012-3456789 (10-12 a.m. or 1-3 p.m.).
<br><br></center></strong>


</body>
</html>